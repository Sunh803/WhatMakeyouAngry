//
//  TimerView.swift
//  SwiftStudentChallenge
//
//  Created by 235 on 2023/04/12.
//

import SwiftUI

struct TimerView: View {
    @State private var timer : Double = 0.0
    @State private var ing : Bool = false
    private var sides = 18.0

    var radius = UIScreen.main.bounds.size.width / 3
    let PI2 = Double.pi * 2
    var random = Double.random(in: 1...20)
    @State private var circlearray = Array<Pos>()

    var body: some View {
        GeometryReader{ geo in
            let center = geo.size.width / 2 - 20
//            let angle = progress * .pi
            ForEach(Array(circlearray.enumerated()), id: \.offset){
                idx, pos in
                ZStack{
                    Circle().frame(width: 40).blur(radius: 20).foregroundColor(.yellow).offset(x: ing ? center : center, y : ing ? center - 50 : center)
                        .animation(.easeOut(duration: 10).repeatForever(), value: ing)
                    Circle().frame(width: 40).blur(radius: 20).foregroundColor(.purple).offset(x: ing ? center + 50 : center , y : ing ? center + 50 : center )
                        .animation(.easeOut(duration: 10).repeatForever(), value: ing)
                    Circle().frame(width: 40).blur(radius: 20).foregroundColor(.blue)
                        .offset(x: ing ? center - 30: center, y : ing ? center + 50 : center)
                            .animation(.easeOut(duration: 10).repeatForever(), value: ing)
                }
                ZStack{
                    Circle().frame(width: 40).opacity(0.5)
                        .foregroundColor(pos.color ? Color.red : Color.green)
                    Circle().frame(width: 50).blur(radius: 12).foregroundColor(pos.color ? Color.red : Color.green)}.offset(x: center + pos.x ,y: center + pos.y)
                .onAppear{
                    ing = true
                    timer += 1.5
                         DispatchQueue.main.asyncAfter(deadline: .now() + timer){
                             withAnimation{
                                 self.circlearray[idx].color = false
                             }
                         }
              
                     }
            }
        }.onAppear{
            let angle  = PI2 / self.sides
            for i in 0...Int(self.sides){
                let x = self.radius * cos(angle * Double(i))
                let y = self.radius * sin(angle * Double(i))
                self.circlearray.append(Pos(x:x, y:y, color: true))
            }
        }
    }
}
struct Pos : Hashable {
    var x :Double
    var y : Double
    var color : Bool
}

