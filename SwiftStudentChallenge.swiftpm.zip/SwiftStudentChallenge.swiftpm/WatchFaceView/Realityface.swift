//
//  SwiftUIView.swift
//  
//
//  Created by 235 on 2023/04/17.
//

import SwiftUI

import UIKit
struct Realityface: View {
    var body: some View {
        ZStack{

            Image("Group 102").resizable().frame(width: 450, height: 550)
        }.frame(maxWidth:  .infinity, maxHeight: .infinity).background(Color(red: 19 / 255, green: 9 / 255, blue: 33 / 255))
    }
}
