//
//  CategorizeView.swift
//  SwiftStudentChallenge
//
//  Created by 235 on 2023/04/14.
//

import SwiftUI

struct CategorizeView: View {
    var TitleText : String
    var examplelist : [String]
    var framewidth : Double
    var frameheight : Int
    var index : Int

    var body: some View {

        ZStack{
            RoundedRectangle(cornerRadius: 20)
                .fill(Color.purple).opacity(0.2)
                .padding()
                .overlay(
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack {
                            ForEach(0..<examplelist.count, id: \.self){i in
                                ButtonView(textlabel: examplelist[i], categorynum: index)
                            }
                        }}.padding(.leading, 30).padding(.trailing, 30))
            Text(TitleText).frame(width: 150, height: 100, alignment: .topLeading).font(.system(size: 15, weight: .black)).foregroundColor(.red).position(x: 100, y: 50)
        }
    }}


