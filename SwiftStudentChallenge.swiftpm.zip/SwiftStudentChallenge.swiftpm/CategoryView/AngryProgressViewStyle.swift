//
//  ProgressView.swift
//  SwiftStudentChallenge
//
//  Created by 235 on 2023/04/14.
//

import SwiftUI

struct AngryProgressViewStyle: ProgressViewStyle {
    @Binding var value : Double
    func makeBody(configuration: Configuration) -> some View {
        return GeometryReader{
            geo in
            VStack(spacing: 0){
                HStack{
                    Image("angry").resizable().scaleEffect(y: 1, anchor: .center)
                        .frame(width: 40, height: 40, alignment: .bottomTrailing).offset(x: value / 3 * geo.size.width - 20)
                    Spacer()
                    Text("🗑️").font(.system(size: 23)).frame(width: 25, height: 30, alignment: .bottomTrailing)
                }
                ProgressView(configuration).accentColor(.red)
            
            }
        }.frame(height: 50)

    }
}
