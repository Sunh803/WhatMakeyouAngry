//
//  SwiftUIView.swift
//  
//
//  Created by 235 on 2023/04/14.
//

import SwiftUI

struct ButtonView: View {
    @EnvironmentObject var list1 : Categorymodel
    @State private var isTapped = false
    var textlabel : String
    var categorynum : Int
      var body: some View {
          Button(action: {changelist()}){
              Text(textlabel).font(.system(size: 14, weight: .semibold)).padding(0.0).frame(width: 55,height: 55).foregroundColor(isTapped ? Color.white : Color.black)
                  .background(isTapped ? Color.red : Color.white)
                  .clipShape(Circle())
          }
      }
    func changelist(){
        self.isTapped.toggle()
        if(self.isTapped == true){
            switch categorynum {
            case 0:
                list1.targetlist.append(textlabel)
            case 2:
                list1.EmotionList.append(textlabel)
            case 3:
                list1.beforeList.append(textlabel)
            default:
               break
            }
        }else{
            switch categorynum {
            case 0:
                list1.targetlist = list1.targetlist.filter({$0 != textlabel})
            case 2:
                list1.EmotionList = list1.EmotionList.filter({$0 != textlabel})
            case 3:
                list1.beforeList = list1.beforeList.filter({$0 != textlabel})
            default:
               break
            }
            
        }
    }
}
