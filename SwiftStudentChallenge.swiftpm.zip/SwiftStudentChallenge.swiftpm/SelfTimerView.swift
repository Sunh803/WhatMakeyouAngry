//
//  SelfTimerView.swift
//  SwiftStudentChallenge
//
//  Created by 235 on 2023/04/11.
//

import SwiftUI
import AVFoundation
struct SelfTimerView: View {
    @State private var gonext = 1
    @State private var finish = false
    @State var player: AVAudioPlayer?
    var body: some View {
            VStack{
                TimerView().onAppear{
                    let timer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true){
                        i in gonext += 1
                        if(gonext == 30){
                            finish = true
                        }
                    }
                }
                Spacer()
                ZStack{
                    RoundedRectangle(cornerRadius: 20).frame(width: 345, height: 125).opacity(0.7).foregroundColor(Color(red: 10 / 255, green: 1 / 255, blue: 0 / 255))
                    VStack{
                        Text("Deep Breath and Know yourself").font(.system(size: 20, weight: .heavy))
                        Text("You can't move next step while you \ntake a deep breath for 30 seconds.\nFeel the anger and look back on you...").font(.system(size: 16, weight: .semibold))}.foregroundColor(.white)
                    NavigationLink(destination: AngryCategoryView().environmentObject(Categorymodel()),isActive: $finish){
                        EmptyView()
                    }
                }.frame(maxWidth: .infinity, maxHeight: .infinity).ignoresSafeArea()
            }.onAppear{
                playBackgroundMusic()
            }.onDisappear{
                player?.stop()
            }.background(Color(red: 19 / 255, green: 9 / 255, blue: 33 / 255))

    }
    private func playBackgroundMusic() {
        guard let path = Bundle.main.path(forResource: "calm", ofType: "mp3") else { return }
        let url = URL(fileURLWithPath: path)
        do {
            player = try AVAudioPlayer(contentsOf: url)
        } catch {
            print("error")
        }
        player?.play()
    }
}

struct SelfTimerView_Previews: PreviewProvider {
    static var previews: some View {
        SelfTimerView()
    }
}


