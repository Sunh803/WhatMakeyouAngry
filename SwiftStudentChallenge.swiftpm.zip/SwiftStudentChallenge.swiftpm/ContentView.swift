import SwiftUI
let customfont = Font.custom("TiquiTaca-Regular", size: 24)
struct ContentView: View {
    @State private var nextpage : Int?
    var body: some View {
        NavigationView{
            ZStack {
                Image("Group 101").resizable().frame(width: 450, height: 550).offset(y:50)
                VStack{
                    Text("What\nMake You\nAngry?").multilineTextAlignment(.center).font(Font.custom("TiquiTaca-Regular", size: 55)).foregroundColor(.white).padding(30)
                    Spacer()
                    NavigationLink(destination: SelfTimerView(), tag: 1, selection : self.$nextpage){
                        EmptyView()
                    }
                    ZStack{
                        Rectangle().fill(Color.gray).blur(radius: 10).opacity(0.5).frame(width: 250,height: 150)
                        Button(action: {
                            self.nextpage = 1
                        }){
                            Text("Get Relieved").font(.system(size: 35, weight: .heavy)).foregroundColor(.black).frame(width: 200, height: 100)
                        }.background(.white).cornerRadius(20).padding(30)
                    }
                }
            }.frame(maxWidth: .infinity).background(Color(red: 19 / 255, green: 9 / 255, blue: 33 / 255))
        }
    }
}

