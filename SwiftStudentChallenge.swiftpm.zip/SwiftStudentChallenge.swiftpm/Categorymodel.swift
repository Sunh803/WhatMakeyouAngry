//
//  Categorymodel.swift
//  SwiftStudentChallenge
//
//  Created by 235 on 2023/04/15.
//

import Foundation
class Categorymodel : ObservableObject  {
    @Published var targetlist : [String] = []
    @Published var howmuchangry : Int = 0
    @Published var EmotionList : [String] = []
    @Published var beforeList : [String] = []
    
}

