//
//  AngryCategoryView.swift
//  SwiftStudentChallenge
//
//  Created by 235 on 2023/04/14.
//

import SwiftUI

struct AngryCategoryView: View {
    @EnvironmentObject private var catemodel : Categorymodel
    @State private var popup : Bool = false
    @State private var xposition : Double = -140.0
    @State private var sliderValue : Double = -140.0
    @State private var faceString : String = "😊"
    @State private var allClicked = false
    @State private var progress : Double = 0.0
    private var targetlist = ["Myself", "Parent", "Friends", "Boss", "Date","World", "other"]
    private var secondlist = ["Sad", "Fear", "Annoy", "Guilty", "Disgust", "Panic","Chaos" ,"Tired", "Awful","Loath","Surly","Other"]
    private var beforelist = ["Happy","Healthy","Lost", "serenity", "thanks", "SoSo", "Love","Bored","Eager","Free","Touch","Other"]
    var assembleList : [String] = []
    
    var body: some View {
        GeometryReader{
            geo in
            let fullwidth = geo.size.width
            
            ZStack{
                VStack(spacing: 20){
                    ProgressView(value: progress, total: 3.0).progressViewStyle(AngryProgressViewStyle(value: $progress)).padding(.leading, 30).padding(.trailing, 30)
                    Text("Find out My Condition").font(.system(size: 35, weight: .semibold)).foregroundColor(.white)
                    CategorizeView(TitleText: "Target", examplelist: targetlist, framewidth : fullwidth / 1.15, frameheight: 100, index: 0)
                    ZStack(alignment: .center){
                        Rectangle()
                            .fill(Color.purple).opacity(0.3).cornerRadius(20)
                            .frame(width: fullwidth / 1.1, height: CGFloat(70)).shadow(radius: 12)
                        Text("Measure of Angry").frame(width: 150, height: 80, alignment: .topLeading).font(.system(size: 15,weight: .black)).foregroundColor(.red).offset(x: -100, y: -10)
                        RoundedRectangle(cornerRadius: 30.0).foregroundColor(.green).frame(width: fullwidth / 1.3, height: 30)
                        RoundedRectangle(cornerRadius: 30.0).foregroundColor(.red).frame(width:  sliderValue + 160, height: 30).offset(x: xposition)
                        Circle().frame(width: 40).foregroundColor(.clear)
                            .overlay(Text(faceString).font(.system(size: 40))).offset(x:  sliderValue).gesture(DragGesture(minimumDistance: 0).onChanged{
                                v in
                                sliderValue = v.location.x
                                if(v.location.x < -140){
                                    sliderValue = -140
                                }
                                if(v.location.x > 140){
                                    sliderValue = 140
                                }
                                xposition = (-160 + sliderValue) / 2
                                if(v.location.x > 40){
                                    faceString = "😡"
                                }
                                else if(v.location.x > -29){
                                    faceString = "🙃"
                                }
                                else{
                                    faceString = "😊"
                                }
                                catemodel.howmuchangry = (Int(sliderValue) + 140) / 28  * 10
                            })
                    }
                    CategorizeView(TitleText: "Emotion", examplelist: secondlist,framewidth : fullwidth / 1.1, frameheight: 100, index : 2)
                    CategorizeView(TitleText: "Before Angry", examplelist: beforelist,framewidth : fullwidth / 1.1, frameheight: 100, index :3)
                    HStack{
                        Spacer()
                        Button(action: {
                            if(allClicked == true){
                                popup = true
                            }
                        }){
                            VStack{
                                Image(systemName: "arrow.right").resizable().frame(width: fullwidth / 6, height: fullwidth / 12).foregroundColor(allClicked ? Color.red : Color.gray)
                                Text("Go Next").foregroundColor(allClicked ? Color.red : Color.gray).font(.system(size: 14,weight: .bold))}
                        }.padding(.trailing, 30)
                    }
                }
                if($popup.wrappedValue){
                    
                    Color(red: 113 / 255, green: 15 / 255, blue: 15 / 255).opacity(0.7).edgesIgnoringSafeArea(.all)
                    
                    VStack(alignment: .center, spacing: 0){
                        Spacer()
                        Text("I am \(catemodel.howmuchangry)% Angry at").font(.system(size: 16, weight: .semibold)).foregroundColor(.red)
                        Text("\(catemodel.targetlist.joined(separator: ", "))").font(.system(size: 16,weight: .bold))
                            .padding(.bottom, 5)
                        Text("Now I'm feeling").font(.system(size: 16, weight: .semibold))
                        Text("\(catemodel.EmotionList.joined(separator: ", ")) right now!").font(.system(size: 16, weight: .black)).padding(.bottom, 5)
                        Text("The feeling right before I got angry \(catemodel.beforeList.count>1 ? "were" : "was")" ).font(.system(size: 14, weight: .medium))
                        Text("\(catemodel.beforeList.joined(separator: ",")).").font(.system(size: 18, weight: .black)).foregroundColor(.green)
                        Spacer()
                        HStack{
                            Spacer()
                            NavigationLink(destination: Realityface()){
                                VStack{
                                    Image(systemName: "arrow.right").resizable().frame(width: fullwidth / 6, height: fullwidth / 12).foregroundColor(.black)
                                    Text("Go Next").foregroundColor(.black).font(.system(size: 14,weight: .bold))}
                            }.padding(.trailing, 30)
                            
                            
                        }
                    }.frame(width: geo.size.width * 3 / 4, height: geo.size.height/3)
                        .background(Color.white).cornerRadius(30)
                }
            }.onAppear{
                Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true){ timer in
                    CheckAllofItem()
                }
            }.frame(maxWidth: .infinity, maxHeight: .infinity).background(Color(red: 19 / 255, green: 9 / 255, blue: 33 / 255))
            
        }
    }
    func CheckAllofItem(){
        if(!catemodel.EmotionList.isEmpty && catemodel.beforeList.isEmpty && catemodel.targetlist.isEmpty){
            progress = 1
        }
        else if(catemodel.EmotionList.isEmpty && !catemodel.beforeList.isEmpty && catemodel.targetlist.isEmpty){
            progress = 1
        }
        else if(catemodel.EmotionList.isEmpty && catemodel.beforeList.isEmpty && !catemodel.targetlist.isEmpty){
            progress = 1
        }
        else if(!catemodel.EmotionList.isEmpty && !catemodel.beforeList.isEmpty && catemodel.targetlist.isEmpty){
            progress = 2
        }
        else if(!catemodel.EmotionList.isEmpty && catemodel.beforeList.isEmpty && !catemodel.targetlist.isEmpty){
            progress = 2
        }
        else if(catemodel.EmotionList.isEmpty && !catemodel.beforeList.isEmpty && !catemodel.targetlist.isEmpty){
            progress = 2
        }
        if(!catemodel.EmotionList.isEmpty && !catemodel.beforeList.isEmpty && !catemodel.targetlist.isEmpty){
            //모두다 클릭을 한 경우
            progress = 3
            allClicked = true
        }
        else{allClicked = false}
    }
}

struct AngryCategoryView_Previews: PreviewProvider {
    static var previews: some View {
        AngryCategoryView()
    }
}
